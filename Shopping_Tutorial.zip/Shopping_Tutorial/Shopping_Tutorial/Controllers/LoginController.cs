﻿namespace Shopping_Tutorial.Controllers
{
	public class LoginController
	{
	}
}
