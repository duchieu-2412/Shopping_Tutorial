﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Shopping_Tutorial.Models;
using Shopping_Tutorial.Repository;
using System.Security.Claims;

namespace Shopping_Tutorial.Controllers
{
	public class CheckoutController:Controller
	{
		private readonly DataContext _dataContext;

		public CheckoutController(DataContext context)
		{
			_dataContext =context;
		}
		public async Task<IActionResult> Checkout()
		{
			var userEmail = User.FindFirstValue(ClaimTypes.Email);
			if(userEmail == null)
			{
				return RedirectToAction("Login", "Account");
			}
			else
			{
				var ordercode = Guid.NewGuid().ToString();
				var oderItem = new OderModel();
				oderItem.OrderCode = ordercode;
				oderItem.UserName = userEmail;
				oderItem.Status = 1;
				oderItem.CreatedDate = DateTime.Now;
				_dataContext.Add(oderItem);
				_dataContext.SaveChanges();
				List<CartItemModel> cartItems = HttpContext.Session.GetJson<List<CartItemModel>>("Cart") ?? new List<CartItemModel>();
				foreach(var cart in cartItems)
				{
					var oderdetails = new OderDetails();
					oderdetails.UserName= userEmail;
					oderdetails.OrderCode= ordercode;
					oderdetails.ProductId= cart.ProductId;
					oderdetails.Price = cart.Price;
					oderdetails.Quantity = cart.Quantity;
					_dataContext.Add(oderdetails);
					_dataContext.SaveChanges();
				}
				HttpContext.Session.Remove("Cart");
				TempData["success"] = "Checkout thành công vui lòng chờ duyệt đơn hàng";
				return RedirectToAction("Index", "Cart");
			}
			return View();
		}
	}
}
